clear
clc
close all

Ts = 0.0001;
fs = 1/Ts;
t = -1:Ts:1-Ts;
N = length(t);
f_sig = 1300;
f_img = 2500;
f_osc1 = 1900;
f_osc2 = 600; 

signal = 1000*sinc(1000*t);
signal_mod = signal.*cos(2*pi*f_sig*t);
image = (500*sinc(500*t).^2).*cos(2*pi*f_img*t);
input = signal_mod + image;
f = -fs/2:fs/N:fs/2 - fs/N;

W1 = 2000;
W2 = 650;

output1 = demod(f_osc1, f_osc2, fs, W1, W2, t, input);
output2 = demod_IR(f_osc1, f_osc2, fs, W1, W2, f, t, input);
%output2 = demod_IR(f_osc1, f_osc2, fs, W1, W2, f, t, input,0);
figure(1)
plot(f, output1)

figure(2)
plot(f, output2)

%deltaF = 0 : 0.02 : 2;
%figure(3)
%plot(deltaF, deltaF.^2/4)
%irr = zeros(1,101);
%temp = 1;
%for i = 0 : 0.02 : 2
%    irr(temp) = mean((output2 - demod_IR(f_osc1, f_osc2, fs, W1, W2, f, t, input,i)).^2);
%    temp = temp + 1;
%end
%figure(4)
%plot(deltaF, irr)
