function [p, t] = pulseShape(pulseName, fs, nSymbolSamples, varargin)
    Ts = nSymbolSamples / fs;
    switch pulseName
        case 'raisedCosine'
            beta = varargin{1};
            spanInSymbol = varargin{2};
            t = -spanInSymbol * Ts / 2 : 1 / fs : (spanInSymbol * Ts /2) - 1 / fs;
            %t = -spanInSymbol * Ts / 2 : 0.2 / fs : (spanInSymbol * Ts /2) - 0.2 / fs;
            t = t';
            p = sinc(t/Ts) .* cos(pi*beta*t/Ts) ./ (1-(2*beta*t/Ts).^2);
            tt = (t((1-(2*beta/Ts*t).^2) == 0));
            p((1-(2*beta*t/Ts).^2) == 0) = pi * sinc(tt/Ts) /4;
        case 'rootRaisedCosine'
            beta = varargin{1};
            spanInSymbol = varargin{2};
            t = -spanInSymbol * Ts / 2 : 1 / fs : (spanInSymbol * Ts /2) - 1 / fs;
            %t = -spanInSymbol * Ts / 2 : 0.2 / fs : (spanInSymbol * Ts /2) - 0.2 / fs;
            t = t';
            p = (1/sqrt(Ts)) .* ((sin(pi*t*(1-beta)/Ts) + (4*beta*t/Ts) .* cos(pi*t*(1+beta)/Ts))./ ((pi*t/Ts) .* (1 - (4*beta*t/Ts).^2)));
        
            p(t == 0) = (1-beta+4*beta/pi)/sqrt(Ts);
            p(t == Ts/(4*beta) | t == -Ts/(4*beta)) = (beta/sqrt(2*Ts))*((1+2/pi)*sin(pi/(4*beta)) + (1-2/pi)*cos(pi/(4*beta)));
        case 'gaussian'
            beta = varargin{1};
            spanInSymbol = varargin{2};
            t = -spanInSymbol * Ts / 2 : 1 / fs : (spanInSymbol * Ts /2) - 1 / fs;
            %t = -spanInSymbol * Ts / 2 : 0.2 / fs : (spanInSymbol * Ts /2) - 0.2 / fs;
            t = t';
            p = (qfunc(2 * pi * beta * (t - Ts/2)) - qfunc(2 * pi * beta * (t + Ts/2))) / log(2);
    end
    p = p / sqrt(abs(p' * p));   %normalize
end