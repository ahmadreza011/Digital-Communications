function output = mylcm(varargin)
    if nargin == 1 && isvector(varargin{1})
        input = varargin{1};
    else
        input = [varargin{:}];
    end
    if any(input <= 0)
            fprintf("negative numbers are not accepted\n")
            output = 0;
    else
        for i = 1 : length(input) - 1
            input(i+1)= lcm(input(i),input(i+1));
        end
        output = input(length(input));
    end
end